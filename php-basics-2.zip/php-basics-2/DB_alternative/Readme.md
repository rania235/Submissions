# DB Alternative

## Purpose
The purpose of this library is to create a local database to store data.

On a real life example data will be stored on a richer db that 
