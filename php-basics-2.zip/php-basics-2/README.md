# PHP basics 2
---
The intention of this exercise is to introduce the Codi intern to the use of PHP.

## TODO:

1. Open the terminal
2. Inside the terminal go to the php exercise path, `cd <path?>`
3. Run the PHP build in server, in the terminal run ` php -S localhost:8000`
4. In the browser open `http://localhost:8000/index.html`

